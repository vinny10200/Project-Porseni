//pure css
/*
https://geometricanimations.tumblr.com/post/132769820883/quad-snake-randomly-found-this-in-my-folders
*/