# Square Snake

A Pen created on CodePen.io. Original URL: [https://codepen.io/Tsankashvili/pen/jmbYGK](https://codepen.io/Tsankashvili/pen/jmbYGK).

Spiral Snake pattern with pure css and creative coding

© Misha Tsankashvili